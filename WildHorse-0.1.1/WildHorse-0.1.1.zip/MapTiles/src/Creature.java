import java.awt.Graphics2D;
import java.util.Random;

public class Creature {
	
	protected float velocity;
	protected short defense, spurn, sight;
	protected int strength, agility, health, maxHealth, attackSpeed, attackRange; //agility - это ловкость
	protected Random random = new Random();
	protected boolean hander, cursed;

	protected boolean attack(Creature creature, Weapon weapon){
		//Attack = 10 + 0.5 * (strength + Rand(agility)) + Bonuses
		int attack = 10 + Math.round((weapon.getAttack()*this.strength/10 + random.nextInt(this.agility))/2);
		return creature.defence(attack);
	}
	
	protected boolean attack(Creature creature){
		//Attack = 10 + 0.5 * (strength + Rand(agility)) + Bonuses
		int attack = 10 + Math.round((this.strength + random.nextInt(this.agility))/2);
		return creature.defence(attack);
	}
	protected boolean defence(int attack){
		//Damage = Attack - Defense
		int damage = attack - this.defense;
		this.health -= damage;
		if(cursed){
			curse();
		}
		if (this.health <= 0){
			return false;
		}else{
			return true;
		}
	}
	protected void curse(){
		this.health -= this.health/10;
	}
	
	protected void drawPoints(Graphics2D g, String color, String value, int x, int y){
		// here goes HP or other render
	}
	public int getHealth(){
		return health;
	}
	public int getMaxHealth(){
		return maxHealth;
	}
	public void setHealth(int health){
		this.health = health;
	}
	public void setMaxHealth(int health){
		this.maxHealth = health;
	}
}
