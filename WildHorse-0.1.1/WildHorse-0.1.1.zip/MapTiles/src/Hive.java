import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;


public class Hive extends Creature{
	
/*
	protected short defense
	protected int health, maxHealth
*/

	private long speed, time;
	private Monster monster;
	private String type;
	private BufferedImage spriteBF;
	private Sprite sprite;
	private int x, y;
	String[] array = {"first","second","third","fourth"};
	Random random = new Random();
	
	public Hive(String string){
		if (string == "blue"){
			loadImages("Blue");
			this.speed = 10000;
			this.type = "second";
		}else if(string == "yellow"){
			loadImages("Yellow");
			this.speed = 13000;
			this.type = "third";
		}else if(string == "red"){
			loadImages("Red");
			this.speed = 15000;
			this.type = "first";
		}else if(string == "orange"){
			loadImages("Orange");
			this.speed = 9000;
			this.type = "fourth";
		}else if(string == "green"){
			loadImages("Random");
			this.speed = 20000;
			this.type = "random";
		}else{
			System.out.println("Invalid hive type!");
			loadImages("Random");
			this.speed = 20000;
			this.type = "random";
		}
		this.maxHealth = (int)(this.speed/10);
		this.health = this.maxHealth;
		this.defense = 0;
	}
	
	private void loadImages(String string){
		java.io.InputStream imgWalkSprite = this.getClass().getClassLoader().getResourceAsStream("hive"+string+".png");
		try {
			spriteBF = ImageIO.read(imgWalkSprite);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		Animation animation = new Animation();
		animation.addScene(spriteBF, 0);
		sprite = new Sprite(animation);
	}
	
	public Monster check() {
		if (time+speed < System.currentTimeMillis()){
			if(this.type != "random"){
				monster = new Monster(type);
			}else{
				monster = new Monster(array[random.nextInt(array.length)]);
			}
			monster.getSprite().setX(random.nextInt(100)+this.getSprite().getX()-50);
			monster.getSprite().setY(random.nextInt(100)+this.getSprite().getY()-50);
			System.out.println(monster.getImage());
			time = System.currentTimeMillis();
			System.out.println(type+" monster is ready");
			return monster;
		}else{
			return null;
		}
	}
	public void setType(String string){
		this.type = string;
	}
	public String getType(){
		return this.type;
	}
	public Sprite getSprite(){
		return this.sprite;
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
}
