import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import javax.imageio.ImageIO;

/**
 * 
 * Attack = 10 + 0.5 * ((strength - 10) + (agility - 10)) + Bonuses
 * Damage = Attack - Defense
 * Health -= damage + curse (if cursed)
 *
 */

public class Monster extends Creature{	
	
	
	private BufferedImage creaturesSprite;
	private int liveAnimation = 4;
	private int dieAnimation = 8;
	
	private BufferedImage allSprites[] = new BufferedImage[liveAnimation+dieAnimation];
	private Sprite sprite, liveSprite, dieSprite;
	private int spriteHeight = 32, spriteWidth = 32;
	private short allMonsters = 3;
	private short number;
	private long time;
	private boolean near = false, dead = false;

	public Monster(String name){
		if (name == "first"){
			velocity = 0.3f; sight = 425; defense = 2;
			health = 40; maxHealth = 40; strength = 10;
			agility = 5; number = 0; attackSpeed = 1000;
			attackRange = 10;
		}else if (name == "second"){
			velocity = 0.2f; sight = 280; defense = 5;
			health = 30; maxHealth = 30; strength = 8;
			agility = 5; number = 1; attackSpeed = 1000;
			attackRange = 10;
		}else if (name == "third"){
			velocity = 0.4f; sight = 150; defense = 3;
			health = 20; maxHealth = 20; strength = 5;
			agility = 5; number = 2; attackSpeed = 1000;
			attackRange = 10;
		}else if (name == "fourth"){
			velocity = 0.5f; sight = 300; defense = 1;
			health = 18; maxHealth = 18; strength = 10;
			agility = 10; number = 3; attackSpeed = 1000;
			attackRange = 10;
		}else{
			System.out.println("unknown monster. Characteristics from first");
			velocity = 0.3f; sight = 425; defense = 2;
			health = 40; maxHealth = 40; strength = 10;
			agility = 5; number = 0; attackSpeed = 1000;
			attackRange = 10;
		}
		loadImages();
	}
	
	public void sight(Hero hero){
		Sprite sprite = hero.getSprite();
		float heroX = hero.getSprite().getX()+hero.getSprite().getWidth()/2;
		float heroY = hero.getSprite().getY()+hero.getSprite().getHeight()/2;
		float monX = this.getSprite().getX()+this.getSprite().getWidth()/2;
		float monY = this.getSprite().getY()+this.getSprite().getHeight()/2;
		long distance = Math.round(Math.sqrt(Math.pow((heroX - monX), 2) + Math.pow((heroY - monY), 2)));
		directionArray[0] = false;
		directionArray[1] = false;
		directionArray[2] = false;
		directionArray[3] = false;
		if (distance < sight){
			if(monX > heroX+sprite.getWidth()*2){
				directionArray[2] = true;
			}else{
				directionArray[2] = false;
			}
			if(monX < heroX-sprite.getWidth()*2){
				directionArray[3] = true;
			}else{
				directionArray[3] = false;
			}
			if(monY < heroY-sprite.getHeight()*2){
				directionArray[1] = true;
			}else{
				directionArray[1] = false;
			}
			if(monY > heroY+sprite.getHeight()*2){
				directionArray[0] = true;
			}else{
				directionArray[0] = false;
			}
		}
		if (distance < attackRange*5){
			long addTime = 0;
			if(!near){
				addTime = 1000;
				near = true;
			}
			if((time + attackSpeed + addTime) < System.currentTimeMillis() && !dead){
				this.attack(hero);
				time = System.currentTimeMillis();
			}
		}else{
			near = false;
		}
		changeVelocity(directionArray);
	}
	public float getVelocity(){
		return velocity;
	}
	public void loadImages(){
		
		java.io.InputStream imgCreaturesSprite = this.getClass().getClassLoader().getResourceAsStream("creaturesSprite.gif");
		try {
			creaturesSprite = ImageIO.read(imgCreaturesSprite);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		for (int i = 0; i < creaturesSprite.getWidth()/(spriteWidth+1); i++)
		{
			BufferedImage sprite = creaturesSprite.getSubimage(i*(spriteWidth+2)+2, spriteHeight*number, spriteWidth, spriteHeight);
			allSprites[i] = sprite;
			BufferedImage sprite2 = creaturesSprite.getSubimage(i*(spriteWidth+2)+2, spriteHeight*(allMonsters+1), spriteWidth, spriteHeight);
			allSprites[i+creaturesSprite.getWidth()/(spriteWidth+1)] = sprite2;
		}

		Animation animation1 = new Animation();
		Animation animation2 = new Animation();
		for(int i = 0; i < liveAnimation; i++){
			animation1.addScene(allSprites[i], 250);
		}
		for (int i = 0; i < dieAnimation; i++){
			animation2.addScene(allSprites[i+liveAnimation], 50);
		}
			liveSprite = new Sprite(animation1);
			liveSprite.setVelocityX(0);
			liveSprite.setVelocityY(0);
			dieSprite = new Sprite(animation2);
			dieSprite.setVelocityX(0);
			dieSprite.setVelocityY(0);
		System.out.println("Monster is ready");
		sprite = liveSprite;
	}
	
	boolean directionArray[] = {false, false, false, false}; // up, down, left, right
	
	public void changeVelocity(boolean directionArray[]){
		if(directionArray[0] == true){
			sprite.setVelocityY(-velocity);
		}else if(directionArray[1] == true){
			sprite.setVelocityY(velocity);
		}else{
			sprite.setVelocityY(0);
		}
		if(directionArray[2] == true){
			sprite.setVelocityX(-velocity);
		}else if(directionArray[3] == true){
			sprite.setVelocityX(velocity);
		}else{
			sprite.setVelocityX(0);
		}
			dieSprite.setX(sprite.getX());
			dieSprite.setY(sprite.getY());
			liveSprite.setX(sprite.getX());
			liveSprite.setY(sprite.getY());
	}

	public Image getImage(){
		return sprite.getImage();
	}
	public Sprite getSprite(){
		return sprite;
	}
	public void die(){
		this.sprite = dieSprite;
		this.dead = true;
	}
}  