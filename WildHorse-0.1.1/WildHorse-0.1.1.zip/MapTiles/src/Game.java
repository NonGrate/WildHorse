import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.util.ArrayList;
import java.util.Random;

public class Game extends Core implements KeyListener, MouseMotionListener,
		MouseListener, MouseWheelListener {
	public static void main(String[] args) {
		new Game().run();
	}

	private String message = "";
	float mouseX, mouseY;
	float dx;
	float dy;
	Map map = new Map();
	Hero hero = new Hero();
	boolean end = false;
	
	Sprite sprite;
	long startTime = System.currentTimeMillis();
	long attackTime;
	long cumulativeTime = startTime;
	boolean directionArray[] = { false, false, false, false }; // up, down,
																// left, right
	int heroWidth, heroHeight, mapXLength, mapYLength, mapTileWidth,
			mapTileHeight, screenHeight, screenWidth;
	float heroVelocity;
	Sprite[] trees, bushes, rocks;
	Object object = new Object();
	Random random = new Random();
	ArrayList<Monster> monsters = new ArrayList<Monster>();
	ArrayList<Hive> hives = new ArrayList<Hive>();

	private void loadImages() {
		// load pics to game (no map pics)
	}

	public void init() {
		monsters.add(new Monster("first"));
		monsters.add(new Monster("second"));
		monsters.add(new Monster("third"));
		monsters.add(new Monster("fourth"));
		monsters.add(new Monster("first"));
		monsters.add(new Monster("second"));
		monsters.add(new Monster("third"));
		monsters.add(new Monster("fourth"));
		
		super.init();
		Window w = s.getFullScreenWindow();
		w.setFocusTraversalKeysEnabled(false); // enable weird buttons?
		w.addMouseListener(this);
		w.addMouseMotionListener(this);
		w.addMouseWheelListener(this);
		w.addKeyListener(this);
		map.main(null);
		hero.loadImages();
		hero.setMaxHealth(50);
		hero.setHealth(hero.getMaxHealth());

		mapXLength = map.mapSpritesArray[0].length;
		mapYLength = map.mapSpritesArray.length;
		mapTileWidth = map.mapSpritesArray[0][0].getWidth();
		mapTileHeight = map.mapSpritesArray[0][0].getHeight();
		screenHeight = s.getHeight();
		screenWidth = s.getWidth();
		heroVelocity = hero.getVelocity();

		hero.getSprite().setX(screenWidth/2);
		hero.getSprite().setY(screenHeight/2);
		hero.setCoordinates();

		hives.add(new Hive("blue"));
		hives.add(new Hive("red"));
		//hives.add(new Hive("orange"));
		//hives.add(new Hive("yellow"));
		hives.add(new Hive("green"));
		//hives.add(new Hive("green"));
		
		for (int i = 0; i < monsters.size(); i++){
		((Monster) monsters.toArray()[i]).getSprite().setX(random.nextInt((mapXLength-8)*mapTileWidth)+100);
		((Monster) monsters.toArray()[i]).getSprite().setY(random.nextInt((mapYLength-8)*mapTileHeight)+100);
		}		
		
		for (int i = 0; i < hives.size(); i++){
		((Hive) hives.toArray()[i]).getSprite().setX(random.nextInt((mapXLength-8)*mapTileWidth)+100);
		((Hive) hives.toArray()[i]).getSprite().setY(random.nextInt((mapYLength-8)*mapTileHeight)+100);
		}

		trees = object.createSpriteArray("tree", 10, false, 600, 600);
		bushes = object.createSpriteArray("bush", 100, true, mapTileWidth*(mapXLength-9), mapTileHeight*(mapYLength-9));
		rocks = object.createSpriteArray("rock", 50, true, mapTileWidth	*(mapXLength-9), mapTileHeight*(mapYLength-9));
		for (int i = 0; i < trees.length; i++){
			trees[i].setX(trees[i].getX()+mapTileWidth*5+20);
			trees[i].setY(trees[i].getY()+mapTileHeight*5+20);
		}
		for (int i = 0; i < bushes.length; i++){
			bushes[i].setX(bushes[i].getX()+mapTileWidth+20);
			bushes[i].setY(bushes[i].getY()+mapTileHeight+20);
		}
		for (int i = 0; i < rocks.length; i++){
			rocks[i].setX(rocks[i].getX()+mapTileWidth+20);
			rocks[i].setY(rocks[i].getY()+mapTileHeight+20);
		}

		loadImages();
		message = "press escape to exit";
	}

	public void checkDXY() {
		if (dy > 0) {
			dy = 0;
		}else if (dy < -(mapYLength-6-(float)screenHeight/(float)mapTileHeight)*mapTileHeight) {
			dy = -(mapYLength - 6 - (float) screenHeight/(float)mapTileHeight)* mapTileHeight;
		}
		if (dx > 0) {
			dx = 0;
		}else if (dx < -(mapXLength-6-(float)screenWidth/(float)mapTileWidth)*mapTileWidth) {
			dx = -(mapXLength-6-(float)screenWidth/(float)mapTileWidth)*mapTileWidth;
		}
	}
	
	public synchronized void draw(Graphics2D g) {
		if (monsters.isEmpty()){
			end = true;
			float alpha = 0.75f;
			Color color = new Color(0, 0, 0, alpha);
			g.setColor(color);
			g.fillRect(0, 0, screenWidth, screenHeight);
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial", Font.BOLD, 40));
			g.drawString("You won!", 100, 100);
			g.setFont(new Font("Arial", Font.BOLD, 30));
			g.drawString("Press enter to exit", 100, 300);
		}else if(hero.getHealth() <= 0){
			end = true;
			float alpha = 0.75f;
			Color color = new Color(0, 0, 0, alpha);
			g.setColor(color);
			g.fillRect(0, 0, screenWidth, screenHeight); 
			g.setColor(Color.WHITE);
			g.setFont(new Font("Arial", Font.BOLD, 40));
			g.drawString("You're dead!", 100, 100);
			g.setFont(new Font("Arial", Font.BOLD, 30));
			g.drawString("Press enter to exit", 100, 300);
		}else{
		for (int i = 0; i < hives.size(); i++){
			Monster mon = ((Hive) hives.toArray()[i]).check();
			if(mon != null){
				monsters.add(mon);
				System.out.println("Added new monster"+i);
			}
		}
		heroWidth = hero.getSprite().getWidth();
		heroHeight = hero.getSprite().getHeight();
		long time = System.currentTimeMillis();
		Window w = s.getFullScreenWindow();
		g.setColor(w.getBackground());
		g.fillRect(0, 0, s.getWidth(), s.getHeight());
		g.setColor(Color.black);
		checkDXY();
		map.renderSprites(g, screenWidth, screenHeight, dx, dy);
		float newDX = dx;
		float newDY = dy;
		hero.changeVelocity(directionArray);
		for (int i = 0; i < bushes.length; i++) {
			g.drawImage(bushes[i].getImage(), Math.round(bushes[i].getX() + newDX), Math.round(bushes[i].getY() + newDY), null);
		}
		for (int i = 0; i < rocks.length; i++) {
			g.drawImage(rocks[i].getImage(), Math.round(rocks[i].getX() + newDX), Math.round(rocks[i].getY() + newDY), null);
		}
		checkDXY();
		
		for (int i = 0; i < hives.size(); i++){
			g.drawImage(((Hive) hives.toArray()[i]).getSprite().getImage(),
					Math.round(((Hive) hives.toArray()[i]).getSprite().getX() + newDX),
					Math.round(((Hive) hives.toArray()[i]).getSprite().getY() + newDY), null);
			g.setColor(Color.BLACK);
			g.fillRect(Math.round(((Hive) hives.toArray()[i]).getSprite().getX() + newDX)-4,
					Math.round(((Hive) hives.toArray()[i]).getSprite().getY() + newDY)-6,
					((Hive) hives.toArray()[i]).getSprite().getWidth()+8, 5);
			g.setColor(Color.RED);
			g.fillRect(Math.round(((Hive) hives.toArray()[i]).getSprite().getX() + newDX)-3,
					Math.round(((Hive) hives.toArray()[i]).getSprite().getY() + newDY)-5,
					Math.round((((Hive) hives.toArray()[i]).getSprite().getWidth()+6)
							*((float)((Hive) hives.toArray()[i]).getHealth()/((Hive) hives.toArray()[i]).getMaxHealth())), 3);
			g.setColor(Color.BLACK);
			
		}
		
		for (int i = 0; i < monsters.size(); i++){
		g.drawImage(((Monster) monsters.toArray()[i])
				.getSprite()
				.getImage(),
				Math.round(((Monster) monsters.toArray()[i]).getSprite().getX() + newDX),
				Math.round(((Monster) monsters.toArray()[i]).getSprite().getY() + newDY), null);
		g.setColor(Color.BLACK);
		g.fillRect(Math.round(((Monster) monsters.toArray()[i]).getSprite().getX() + newDX)-4,
				Math.round(((Monster) monsters.toArray()[i]).getSprite().getY() + newDY)-6,
				((Monster) monsters.toArray()[i]).getSprite().getWidth()+8, 5);
		g.setColor(Color.RED);
		g.fillRect(Math.round(((Monster) monsters.toArray()[i]).getSprite().getX() + newDX)-3,
				Math.round(((Monster) monsters.toArray()[i]).getSprite().getY() + newDY)-5,
				Math.round((((Monster) monsters.toArray()[i]).getSprite().getWidth()+6)
						*((float)((Monster) monsters.toArray()[i]).getHealth()/((Monster) monsters.toArray()[i]).getMaxHealth())), 3);
		g.setColor(Color.BLACK);
		
		}

		
		g.drawImage(hero.getImage(),
				Math.round(hero.getSprite().getX() + dx),
				Math.round(hero.getSprite().getY() + dy), null);
		//g.drawImage(hero.getWeaponSprite().getImage(), Math.round(hero.getSprite().getX() + dx), Math.round(hero.getSprite().getY() + dy), null);
		g.drawString(hero.getWeapon().getName(), Math.round(hero.getSprite().getX() + dx), Math.round(hero.getSprite().getY() + dy));
		
		//message = ""+hero.getSprite().getY();
		for (int i = 0; i < trees.length; i++) {
			g.drawImage(trees[i].getImage(), Math.round(trees[i].getX() + newDX), Math.round(trees[i].getY() + newDY), null);
			//g.drawRect(Math.round(trees[i].getX() + newDX), Math.round(trees[i].getY() + newDY), trees[i].getWidth(), trees[i].getHeight());
			//g.drawString(""+i, Math.round(trees[i].getX() + newDX), Math.round(trees[i].getY() + newDY));
		}
		g.setColor(Color.black);
		g.fillRect(0, 0, 57, 55);
		g.setColor(Color.white);
		message = "" + (System.currentTimeMillis() - time);
		g.drawString(message, 15, 30);

		long timePassed = System.currentTimeMillis() - cumulativeTime;
		cumulativeTime += timePassed;
		testXY(hero.getSprite(), timePassed);
		
		//walkThrough(hero.getSprite(), trees, timePassed, g);
		//walkThrough(hero.getSprite(), bushes, timePassed);
		//walkThrough(hero.getSprite(), rocks, timePassed);
		hero.getSprite().update(timePassed);
		
		for(int i = 0; i < monsters.size(); i++){
			((Monster) monsters.toArray()[i]).sight(hero);
			((Monster) monsters.toArray()[i]).getSprite().update(timePassed);
		}
		drawStats(g);
		}
	}

	// удары о края карты и движение экрана у его краев
	private void testXY(Sprite sprite, long time) {
		heroWidth = sprite.getWidth();
		heroHeight = sprite.getHeight();
		float heroX = sprite.getX();
		float heroY = sprite.getY();

		// это отвечает за края экрана
		if ((heroX + heroWidth) < (screenWidth - dx)
				&& (heroX + heroWidth) > (screenWidth-mapTileWidth*2)-dx) {
			dx -= heroVelocity * time;
		}
		if (heroX > -dx && heroX < mapTileWidth - dx) {
			dx += heroVelocity * time;
		}
		if ((heroY + heroHeight) < (screenHeight - dy)
				&& (heroY + heroHeight) > (screenHeight-mapTileHeight*2)-dy) {
			dy -= heroVelocity * time;
		}
		if (heroY > -dy && heroY < mapTileHeight - dy) {
			dy += heroVelocity * time;
		}
		
		// этот код отвечает за края карты
		if (sprite.getY() < mapTileHeight) {
			directionArray[0] = false;
			sprite.setY(mapTileHeight);
		} else if (heroY + heroHeight > mapTileHeight * (mapYLength - 7)) {
			directionArray[1] = false;
			sprite.setY(mapTileHeight * (mapYLength - 7) - heroHeight);
		}
		if (heroX < mapTileWidth) {
			directionArray[2] = false;
			sprite.setX(mapTileWidth);
		} else if (heroX + heroWidth > mapTileWidth * (mapXLength-7)) {
			directionArray[3] = false;
			sprite.setX(mapTileWidth * (mapXLength-7) - heroWidth);
		}
	}
	
	private void drawStats(Graphics2D g){
		g.setColor(new Color(220, 20, 20));
		g.setStroke(new BasicStroke(5.0f));
		g.drawRoundRect(screenWidth-203, screenHeight-83, 223, 103, 10, 10);
		g.setStroke(new BasicStroke(1.0f));
		g.setColor(new Color(0, 0, 0, 0.6f));
		g.fillRect(screenWidth-200, screenHeight-80, 200, 80);
		g.setColor(Color.RED);
		g.drawString("HP: ", screenWidth-190, screenHeight-50);
		g.drawRect(screenWidth-150, screenHeight-68, 135, 20);
		g.fillRect(screenWidth-150, screenHeight-68, Math.round(135*((float)hero.getHealth()/hero.getMaxHealth())), 20);
		g.setColor(Color.WHITE);
		g.drawString("W: "+hero.getWeapon().getName(), screenWidth-190, screenHeight-20);
		g.drawString("AP: "+hero.getWeapon().getAttack(), screenWidth-100, screenHeight-20);
	}
	
	// проверка, чтобы чел стукался о преграды
	private void walkThrough(Sprite sprite, Sprite[] spriteArray, long time, Graphics2D g) {
		if (!spriteArray[0].isWalkThough()) {
			Point q = new Point(Math.round(sprite.getX()+dx),Math.round(sprite.getY()+dy));
			Point w = new Point(Math.round(sprite.getX()+sprite.getWidth()+dx),Math.round(sprite.getY()+dy));
			Point s = new Point(Math.round(sprite.getX()+sprite.getWidth()+dx),Math.round(sprite.getY()+sprite.getHeight()+dy));
			Point a = new Point(Math.round(sprite.getX()+dx),Math.round(sprite.getY()+sprite.getHeight()+dy));
			for (int i = 0; i < spriteArray.length; i++) {
				Rectangle rec = new Rectangle(Math.round(spriteArray[i].getX()+dx+spriteArray[i].getWidth()/3),
												(int)Math.round(spriteArray[i].getY()+dy+spriteArray[i].getHeight()*0.75),
												spriteArray[i].getWidth()/3,
												spriteArray[i].getHeight()/3);
				g.draw(rec);
				if (rec.contains(q) || rec.contains(w) || rec.contains(s) || rec.contains(a)){
					
					if(sprite.getX()+sprite.getWidth() > q.getX() && sprite.getX()+sprite.getWidth() < w.getX()-w.getX()/2-2){
						sprite.setX(sprite.getX() + sprite.getVelocityX()*time);
					}else if(sprite.getX() > w.getX()-w.getX()/2+2 && sprite.getX() < w.getX()){
						sprite.setX(sprite.getX() - sprite.getVelocityX()*time);
					}
					
					//if(sprite.getY() > q.getY() && sprite.getY() > w.getY()){
					//	sprite.setY(sprite.getY() - sprite.getVelocityY()*time);
					//}else if(sprite.getY() < a.getY() && sprite.getY() < s.getY()){
					//	sprite.setY(sprite.getY() + sprite.getVelocityY()*time);
					//}
					
				}
			}
		}
	}

	public void killMonster(int i, long time){
		((Monster) monsters.toArray()[i]).die();
		try {
			Thread.sleep(350);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		monsters.remove(i);
	}
	
	public void spurnMonster(int i){
		float heroX = hero.getSprite().getX()+hero.getSprite().getWidth()/2;
		float heroY = hero.getSprite().getY()+hero.getSprite().getHeight()/2;
		float monX = ((Monster) monsters.toArray()[i]).getSprite().getX()+((Monster) monsters.toArray()[i]).getSprite().getWidth()/2;
		float monY = ((Monster) monsters.toArray()[i]).getSprite().getY()+((Monster) monsters.toArray()[i]).getSprite().getHeight()/2;
		
		long distanceOne = Math.round(Math.sqrt(Math.pow((heroX - monX), 2)+Math.pow((heroY - monY), 2)));
		int distanceTwo = hero.getSpurn()*2;

		((Monster) monsters.toArray()[i]).getSprite().setX(heroX+(distanceTwo*(monX-heroX))/distanceOne);
		((Monster) monsters.toArray()[i]).getSprite().setY(heroY+(distanceTwo*(monY-heroY))/distanceOne);
//		((Monster) monsters.toArray()[i]).getSprite().setX(heroX+100);
//		((Monster) monsters.toArray()[i]).getSprite().setY(heroY+100);
	}
	
	// key pressed
	public void keyPressed(KeyEvent e) {
		int keyCode = e.getKeyCode();
		if (end){
			if (keyCode == KeyEvent.VK_ENTER){
				stop();
			}
		}
		if (keyCode == KeyEvent.VK_ESCAPE) {
			stop();
		}else if(keyCode == KeyEvent.VK_SPACE){
			if (attackTime+hero.getWeapon().getAttackSpeed() <= System.currentTimeMillis() || attackTime == 0){
				float heroX = hero.getSprite().getX()+hero.getSprite().getWidth()/2;
				float heroY = hero.getSprite().getY()+hero.getSprite().getHeight()/2;
				for (int i = 0; i < hives.size(); i++) {
					float hiveX = ((Hive) hives.toArray()[i]).getSprite().getX()+((Hive) hives.toArray()[i]).getSprite().getWidth()/2;
					float hiveY = ((Hive) hives.toArray()[i]).getSprite().getY()+((Hive) hives.toArray()[i]).getSprite().getHeight()/2;
					long distance = Math.round(Math.pow((heroX-hiveX), 2)+Math.pow((heroY-hiveY), 2));
					if (Math.sqrt(distance) < hero.getWeapon().getAttackRange()*5){
						if (!hero.attack(((Hive) hives.toArray()[i]), hero.getWeapon())){
							hives.remove(i);
							break;
						}
					}
				}
				for (int i = 0; i < monsters.size(); i++) {
					float monsterX = ((Monster) monsters.toArray()[i]).getSprite().getX()+((Monster) monsters.toArray()[i]).getSprite().getWidth()/2;
					float monsterY = ((Monster) monsters.toArray()[i]).getSprite().getY()+((Monster) monsters.toArray()[i]).getSprite().getHeight()/2;
					long distance = Math.round(Math.pow((heroX-monsterX), 2)+Math.pow((heroY-monsterY), 2));
					if (Math.sqrt(distance) < hero.getWeapon().getAttackRange()*5){
						if (!hero.attack(((Monster) monsters.toArray()[i]), hero.getWeapon())){
							killMonster(i, System.currentTimeMillis());
							break;
						}else{
							spurnMonster(i);
						}
					}
				}
				attackTime = System.currentTimeMillis();
			}
			
		}else {
			sprite = hero.getSprite();
			if (keyCode == KeyEvent.VK_1) {
				hero.takeWeapon(new Weapon("axe"));
			}else if(keyCode == KeyEvent.VK_2){
				hero.takeWeapon(new Weapon ("bow"));
			}else if(keyCode == KeyEvent.VK_3){
				hero.takeWeapon(new Weapon ("sword"));
			}else if(keyCode == KeyEvent.VK_4){
				hero.takeWeapon(new Weapon ("stick"));
			}else if(keyCode == KeyEvent.VK_5){
				hero.takeWeapon(new Weapon ("spear"));
			}else if(keyCode == KeyEvent.VK_6){
				hero.takeWeapon(new Weapon ("sling"));
			}else if(keyCode == KeyEvent.VK_7){
				hero.takeWeapon(new Weapon ("hammer"));
			}else if(keyCode == KeyEvent.VK_8){
				hero.takeWeapon(new Weapon ("crossbow"));
			}else if(keyCode == KeyEvent.VK_9){
				hero.takeWeapon(new Weapon ("long sword"));
			}else if(keyCode == KeyEvent.VK_0){
				hero.takeWeapon(new Weapon ("none"));
			}
			if (keyCode == KeyEvent.VK_UP) {
				if (sprite.getY() > 0) {
					directionArray[0] = true;
				}
			}
			if (keyCode == KeyEvent.VK_DOWN) {
				if (sprite.getY() + heroHeight < mapTileHeight*(mapYLength - 6)) {
					directionArray[1] = true;
				}
			}
			if (keyCode == KeyEvent.VK_RIGHT) {
				if (sprite.getX() + heroWidth < mapTileWidth*(mapXLength - 6)) {
					directionArray[3] = true;
				}
			}
			if (keyCode == KeyEvent.VK_LEFT) {
				if (sprite.getX() > 0) {
					directionArray[2] = true;
				}
			}
			message = "Pressed: " + KeyEvent.getKeyText(keyCode);
			e.consume();
		}
	}

	// key released
	public void keyReleased(KeyEvent e) {
		int keyCode = e.getKeyCode();
		if (keyCode == KeyEvent.VK_UP) {
			directionArray[0] = false;
		}
		if (keyCode == KeyEvent.VK_DOWN) {
			directionArray[1] = false;
		}
		if (keyCode == KeyEvent.VK_RIGHT) {
			directionArray[3] = false;
		}
		if (keyCode == KeyEvent.VK_LEFT) {
			directionArray[2] = false;
		}
		if (keyCode == KeyEvent.VK_H) {
			hero.setHealth(hero.getHealth()+hero.getMaxHealth()/3);
			if (hero.getHealth() > hero.getMaxHealth()){
				hero.setHealth(hero.getMaxHealth());
			}
		}
		e.consume();
	}

	public void keyTyped(KeyEvent e) {
		e.consume();
	}
	public void mousePressed(MouseEvent e) {
		message = "you pressed down the mouse";
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseReleased(MouseEvent e) {
		message = "you released the mouse";
	}
	public void mouseClicked(MouseEvent e) {
	}
	public void mouseEntered(MouseEvent e) {
	}
	public void mouseExited(MouseEvent e) {
	}
	public void mouseDragged(MouseEvent e) {
		dx += e.getX() - mouseX;
		dy += e.getY() - mouseY;
		message = "you are dragging the mouse\n" + dx + "|" + dy;
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseMoved(MouseEvent e) {
		message = ""+e.getX()+"X"+e.getY();
		
	}
	public void mouseWheelMoved(MouseWheelEvent e) {
		message = "moving mouse wheel";
	}
	public void addToArrayList(Monster monster){
		monsters.add(monster);
	}
}