import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;

import javax.imageio.ImageIO;


public class Object {

	private BufferedImage object;
	private float x, y;
	Sprite sprite;
	ArrayList<Sprite> spriteArrayList = new ArrayList<Sprite>();
	
	private Sprite createSprite(String string, float x,float y, boolean bool){
		java.io.InputStream imgObject = this.getClass().getClassLoader().getResourceAsStream(string + ".gif");
		try {
			object = ImageIO.read(imgObject);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		this.x = x;
		this.y = y;
		Animation animation = new Animation();
		animation.addScene(object, 0);
		Sprite sprite = new Sprite(animation);
		sprite.setVelocityX(0);
		sprite.setVelocityY(0);
		sprite.setX(x);
		sprite.setY(y);
		sprite.setWalkThough(bool);
		return sprite;
	}
	
	public Sprite[] createSpriteArray(String string, int num, boolean walk, int x, int y){
		Random random = new Random();
		Sprite[] spriteArray = new Sprite[num];
		for (int i = 0; i < num; i++){
			int newX = random.nextInt(x);
			int newY = random.nextInt(y);
		spriteArray[i] = createSprite(string, newX, newY, walk);
		if(!walk){
			//spriteArray[i].setFX(newX);
			//spriteArray[i].setFY(newX);
			//spriteArray[i].setLX(newX+spriteArray[i].getWidth());
			//spriteArray[i].setLY(newY+spriteArray[i].getHeight());
		}
		}
		return spriteArray;
	}
	public Sprite[] createSpriteArray(String string, boolean walk, float x, float y){
		spriteArrayList.add(createSprite(string, x, y, true));
		Sprite[] spriteArray = new Sprite[spriteArrayList.size()];
		spriteArray = (Sprite[])spriteArrayList.toArray();
		return spriteArray;
	}	
}
