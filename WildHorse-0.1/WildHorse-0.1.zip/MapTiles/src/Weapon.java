import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;


public class Weapon {
	
	private int attack, attackRange, spriteWidth = 32, spriteHeight = 39, horizontal = 7, attackBonus, attackSpeed;
	private String type, name;

	private Sprite runSprites[] = new Sprite[8], staySprites[] = new Sprite[8], attackSprites[] = new Sprite[8];
	private Sprite runBehindSprites[] = new Sprite[8], stayBehindSprites[] = new Sprite[8], attackBehindSprites[] = new Sprite[8];

	private BufferedImage weaponSprite, weaponBehindSprite;
	
	public Weapon(String name){
		java.io.InputStream imgsSprite = this.getClass().getClassLoader().getResourceAsStream("weaponSprite.gif");

		java.io.InputStream imgsBehindSprite = this.getClass().getClassLoader().getResourceAsStream("weaponBehindSprite.gif");
		try {
			weaponSprite = ImageIO.read(imgsSprite);
			weaponBehindSprite = ImageIO.read(imgsBehindSprite);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		if (name == "axe"){
			makeSprites(0, 20, 10, 750, "oneHand");
			this.type = "oneHand";
		}else if (name == "bow"){
			makeSprites(0, 10, 50, 750, "bow");
			this.type = "oneHand";
		}else if (name == "crossbow"){
			makeSprites(0, 30, 70, 1500, "twoHand");
			this.type = "oneHand";
		}else if (name == "hammer"){
			makeSprites(0, 20, 15, 750, "twoHand");
			this.type = "oneHand";
		}else if (name == "long stick"){
			makeSprites(0, 15, 15, 400, "oneHand");
			this.type = "oneHand";
		}else if (name == "long sword"){
			makeSprites(0, 25, 15, 750, "twoHand");
			this.type = "oneHand";
		}else if (name == "none"){
			makeSprites(0, 5, 5, 250, "none");
			this.type = "oneHand";
		}else if (name == "pickaxe"){
			makeSprites(0, 15, 15, 750, "twoHand");
			this.type = "oneHand";
		}else if (name == "sling"){
			makeSprites(0, 8, 25, 1000, "none");
			this.type = "oneHand";
		}else if (name == "spear"){
			makeSprites(0, 10, 15, 500, "twoHand");
			this.type = "oneHand";
		}else if (name == "stick"){
			makeSprites(0, 7, 10, 250, "oneHand");
			this.type = "oneHand";
		}else if (name == "stone"){
			makeSprites(0, 7, 20, 200, "none");
			this.type = "oneHand";
		}else if (name == "sword"){
			makeSprites(0, 15, 10, 500, "oneHand");
			this.type = "oneHand";
		}else{
			makeSprites(0, 5, 5, 250, "none");
			this.type = "none";
		}
		System.out.println(name+" is ready");
		this.name = name;
	}
	
	private void makeSprites(int num, int attack, int attackRange, int attackSpeed, String type){
		for (int i = 0; i < 8; i++){
			Animation run = new Animation();
			Animation stay = new Animation();
			Animation attackAnimation = new Animation();
			Animation runB = new Animation();
			Animation stayB = new Animation();
			Animation attackAnimationB = new Animation();
			for (int j = 0; j < horizontal; j++){
				BufferedImage sprite = weaponSprite.getSubimage(j*spriteWidth, (i+1)*spriteHeight*num*8, spriteWidth, spriteHeight);
				BufferedImage sprite2 = weaponSprite.getSubimage(j*spriteWidth, (i+9)*spriteHeight*num*8, spriteWidth, spriteHeight);
				BufferedImage spriteB = weaponBehindSprite.getSubimage(j*spriteWidth, (i+1)*spriteHeight*num*8, spriteWidth, spriteHeight);
				BufferedImage spriteB2 = weaponBehindSprite.getSubimage(j*spriteWidth, (i+9)*spriteHeight*num*8, spriteWidth, spriteHeight);
				run.addScene(sprite, 100);
				attackAnimation.addScene(sprite2, 100);
				runB.addScene(spriteB, 100);
				attackAnimationB.addScene(spriteB2, 100);
				if (j == 0){
					stay.addScene(sprite, 0);
					staySprites[i] = new Sprite(stay);
					stayB.addScene(spriteB, 0);
					stayBehindSprites[i] = new Sprite(stay);
				}
			}
			runSprites[i] = new Sprite(run);
			runSprites[i].setVelocityX(0);
			runSprites[i].setVelocityY(0);
			staySprites[i].setVelocityX(0);
			staySprites[i].setVelocityY(0);
			attackSprites[i] = new Sprite(attackAnimation);
			attackSprites[i].setVelocityX(0);
			attackSprites[i].setVelocityY(0);
			
			runBehindSprites[i] = new Sprite(runB);
			runBehindSprites[i].setVelocityX(0);
			runBehindSprites[i].setVelocityY(0);
			stayBehindSprites[i].setVelocityX(0);
			stayBehindSprites[i].setVelocityY(0);
			attackBehindSprites[i] = new Sprite(attackAnimationB);
			attackBehindSprites[i].setVelocityX(0);
			attackBehindSprites[i].setVelocityY(0);
		}
		this.attack = attack;
		this.attackRange = attackRange;
		this.attackSpeed = attackSpeed;
	}

	public String getType(){
		return this.type;
	}
	public String getName(){
		return this.name;
	}
	public void setBonus(int i){
		this.attackBonus = i;
	}
	public int getBonus(){
		return this.attackBonus;
	}
	public int getAttack(){
		return this.attack;
	}
	public int getAttackRange(){
		return this.attackRange;
	}
	public int getAttackSpeed(){
		return this.attackSpeed;
	}
	public Sprite[] getRunSprite(){
		return this.runSprites;
	}
	public Sprite[] getStaySprite(){
		return this.staySprites;
	}
	public Sprite[] getAttackSprite(){
		return this.attackSprites;
	}
	public Sprite[] getRunBehindSprite(){
		return this.runBehindSprites;
	}
	public Sprite[] getStayBehindSprite(){
		return this.stayBehindSprites;
	}
	public Sprite[] getAttackBehindSprite(){
		return this.attackBehindSprites;
	}
}
