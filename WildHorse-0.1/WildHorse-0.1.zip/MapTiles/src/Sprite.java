import java.awt.Image;
import java.awt.Point;
import java.awt.Rectangle;

public class Sprite {
	private Animation a;
	private float x;
	private float y;
	private float vx;
	private float vy;
	private boolean walkThrough;
	private float lx, ly;
	
	public Sprite(Animation a){
		this.a = a;
	}
	public void update(long timePassed){
		x += vx * timePassed;
		y += vy * timePassed;
		a.update(timePassed);
	}
	public boolean isWalkThough(){
		return this.walkThrough;
	}
	public void setWalkThough(boolean walk){
		this.walkThrough = walk;
	}
	public float getX(){
		return x;
	}
	public float getY(){
		return y;
	}
	public void setX(float x){
		this.x = x;
		this.lx = this.x + this.getWidth();
	}
	public void setY(float y){
		this.y = y;
		this.ly = this.y + this.getHeight();
	}
	public float getLX(){
		return lx;
	}
	public float getLY(){
		return ly;
	}
	public int getWidth(){
		return a.getImage().getWidth(null);
	}
	public int getHeight(){
		return a.getImage().getHeight(null);
	}
	public float getVelocityX(){
		return vx;
	}
	public float getVelocityY(){
		return vy;
	}
	public void setVelocityX(float vx){
		this.vx = vx;
	}
	public void setVelocityY(float vy){
		this.vy = vy;
	}
	public Image getImage(){
		return a.getImage();
	}
}
