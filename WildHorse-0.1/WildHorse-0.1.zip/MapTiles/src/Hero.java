import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Hero extends Creature{

	private BufferedImage walkSprite;
	
	private Sprite moveArray[] = new Sprite[8], stayArray[] = new Sprite[8], attackArray[] = new Sprite[8];
	private Sprite weaponMoveArray[] = new Sprite[8], weaponStayArray[] = new Sprite[8], weaponAttackArray[] = new Sprite[8];
	private Sprite behindMoveArray[] = new Sprite[8], behindStayArray[] = new Sprite[8], behindAttackArray[] = new Sprite[8];
	
	private Sprite runSpritesArray[] = new Sprite[8], staySpritesArray[] = new Sprite[8], attackSpritesArray[] = new Sprite[8];
	private Sprite swimSpritesArray[] = new Sprite[8], swimStaySpritesArray[] = new Sprite[8];

	private Sprite bowSpritesArray[] = new Sprite[8], bowStaySpritesArray[] = new Sprite[8], bowAttackSpritesArray[] = new Sprite[8];
	private Sprite crossbowSpritesArray[] = new Sprite[8], crossbowStaySpritesArray[] = new Sprite[8], crossbowAttackSpritesArray[] = new Sprite[8];
	private Sprite oneHandSpritesArray[] = new Sprite[8], oneHandStaySpritesArray[] = new Sprite[8], oneHandAttackSpritesArray[] = new Sprite[8];
	private Sprite twoHandSpritesArray[] = new Sprite[8], twoHandStaySpritesArray[] = new Sprite[8], twoHandAttackSpritesArray[] = new Sprite[8];

	private Sprite sprite, weaponSprite, behindSprite;
	private Weapon weapon = new Weapon("axe");
	private Weapon weaponBehind = new Weapon("axe");
	private int spriteHeight = 26, spriteWidth = 24, spriteHeight2 = 39, spriteWidth2 = 32, stayDirection = 0;
	private float velocity = 0.15f;
	
	public float getVelocity(){
		return velocity;
	}
	public void loadImages(){
		
		this.agility = 10;
		this.defense = 10;
		this.strength = 20;
		
		java.io.InputStream imgWalkSprite = this.getClass().getClassLoader().getResourceAsStream("greenSprites4.gif");
		try {
			walkSprite = ImageIO.read(imgWalkSprite);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		System.out.println("Creating sprites");
		for (int i = 0; i < 16; i++)
		{
			Animation animationRun = new Animation();
			Animation animationStay = new Animation();
			Animation animationAttack = new Animation();
			Animation animationSwim = new Animation();
			Animation animationSwimStay = new Animation();
			if (i < 8){
				for (int j = 0; j < 10; j++)
				{	
					BufferedImage sprite = walkSprite.getSubimage(j*spriteWidth, i*spriteHeight, spriteWidth, spriteHeight);
					animationRun.addScene(sprite, 100);
					BufferedImage sprite2 = walkSprite.getSubimage(j*spriteWidth, (i+8)*spriteHeight, spriteWidth, spriteHeight);
					animationAttack.addScene(sprite2, 100);
					if(j == 0){
						BufferedImage stay = walkSprite.getSubimage(0, i*spriteHeight, spriteWidth, spriteHeight);
						animationStay.addScene(stay, 0);
						staySpritesArray[i] = new Sprite(animationStay);
					}
				}
				runSpritesArray[i] = new Sprite(animationRun);
				runSpritesArray[i].setVelocityX(0);
				runSpritesArray[i].setVelocityY(0);
				attackSpritesArray[i] = new Sprite(animationAttack);
				attackSpritesArray[i].setVelocityX(0);
				attackSpritesArray[i].setVelocityY(0);
				staySpritesArray[i].setVelocityX(0);
				staySpritesArray[i].setVelocityY(0);
			
			}else if (i < 16){
				for (int j = 0; j < 10; j++){
					BufferedImage sprite = walkSprite.getSubimage(j*spriteWidth, i*spriteHeight, spriteWidth, spriteHeight);
					animationSwim.addScene(sprite, 100);
					if(j == 0){
						BufferedImage stay = walkSprite.getSubimage(0, i*spriteHeight, spriteWidth, spriteHeight);
						animationSwimStay.addScene(stay, 0);
						swimStaySpritesArray[i-8] = new Sprite(animationSwimStay);
					}
					}
				
			swimSpritesArray[i-8] = new Sprite(animationSwim); // d, dr, r, ur, u, ul, l, dl
			swimSpritesArray[i-8].setVelocityX(0);
			swimSpritesArray[i-8].setVelocityY(0);
			swimStaySpritesArray[i-8].setVelocityX(0);
			swimStaySpritesArray[i-8].setVelocityY(0);
			}
		}

		makeSprites(416, oneHandSpritesArray, oneHandStaySpritesArray, oneHandAttackSpritesArray);
		makeSprites(416, twoHandSpritesArray, twoHandStaySpritesArray, twoHandAttackSpritesArray);
		makeSprites(416, bowSpritesArray, bowStaySpritesArray, bowAttackSpritesArray); // 1248
		makeSprites(416, crossbowSpritesArray, crossbowStaySpritesArray, crossbowAttackSpritesArray); // 1560

		System.out.println("Hero move array is ready");
		sprite = staySpritesArray[0];
		for (int i = 0; i < 8; i++){
			moveArray[i] = runSpritesArray[i];
			stayArray[i] = staySpritesArray[i];
		}
		
		weaponMoveArray = weapon.getRunSprite();
		weaponStayArray = weapon.getStaySprite();
		weaponAttackArray = weapon.getAttackSprite();
		behindMoveArray = weaponBehind.getRunBehindSprite();
		behindStayArray = weaponBehind.getStayBehindSprite();
		behindAttackArray = weaponBehind.getAttackBehindSprite();
		
	}
	
	
	private void makeSprites(int num, Sprite[] runSprites, Sprite[] staySprites, Sprite[] attackSprites){
		for (int i = 0; i < 8; i++){
			Animation run = new Animation();
			Animation stay = new Animation();
			Animation attack = new Animation();
			for (int j = 0; j < 7; j++){
				BufferedImage sprite = walkSprite.getSubimage(j*spriteWidth2, (i)*spriteHeight2+num, spriteWidth2, spriteHeight2);
				BufferedImage sprite2 = walkSprite.getSubimage(j*spriteWidth2, (i+8)*spriteHeight2+num, spriteWidth2, spriteHeight2);
				run.addScene(sprite, 100);
				attack.addScene(sprite2, 100);
				if (j == 0){
					stay.addScene(sprite, 0);
					staySprites[i] = new Sprite(stay);
				}
			}
			runSprites[i] = new Sprite(run);
			runSprites[i].setVelocityX(0);
			runSprites[i].setVelocityY(0);
			staySprites[i].setVelocityX(0);
			staySprites[i].setVelocityY(0);
			attackSprites[i] = new Sprite(attack);
			attackSprites[i].setVelocityX(0);
			attackSprites[i].setVelocityY(0);
		}
	}
	
	boolean directionArray[] = {false, false, false, false}; // up, down, left, right
	
	public void setSprites(){
		if(weapon.getType() == "none"){
			for (int i = 0; i < 8; i++){
				moveArray[i] = runSpritesArray[i];
				stayArray[i] = staySpritesArray[i];
				attackArray[i] = attackSpritesArray[i];
			}
		}else if (weapon.getType() == "oneHand"){
			for (int i = 0; i < 8; i++){
				moveArray[i] = oneHandSpritesArray[i];
				stayArray[i] = oneHandStaySpritesArray[i];
				attackArray[i] = oneHandAttackSpritesArray[i];
			}
		}else if (weapon.getType() == "twoHand"){
			for (int i = 0; i < 8; i++){
				moveArray[i] = twoHandSpritesArray[i];
				stayArray[i] = twoHandStaySpritesArray[i];
				attackArray[i] = twoHandAttackSpritesArray[i];
			}
		}else if (weapon.getType() == "bow"){
			for (int i = 0; i < 8; i++){
				moveArray[i] = bowSpritesArray[i];
				stayArray[i] = bowStaySpritesArray[i];
				attackArray[i] = bowAttackSpritesArray[i];
			}
		}else{
			for (int i = 0; i < 8; i++){
				moveArray[i] = runSpritesArray[i];
				stayArray[i] = staySpritesArray[i];
				attackArray[i] = attackSpritesArray[i];
			}
		}
	}
	
	public void setCoordinates(){
		for(int i=0; i < moveArray.length; i++){
			runSpritesArray[i].setX(sprite.getX());
			runSpritesArray[i].setY(sprite.getY());
			staySpritesArray[i].setX(sprite.getX());
			staySpritesArray[i].setY(sprite.getY());
			attackSpritesArray[i].setX(sprite.getX());
			attackSpritesArray[i].setY(sprite.getY());
			swimSpritesArray[i].setX(sprite.getX());
			swimSpritesArray[i].setY(sprite.getY());
			swimStaySpritesArray[i].setX(sprite.getX());
			swimStaySpritesArray[i].setY(sprite.getY());
			bowSpritesArray[i].setX(sprite.getX());
			bowSpritesArray[i].setY(sprite.getY());
			bowStaySpritesArray[i].setX(sprite.getX());
			bowStaySpritesArray[i].setY(sprite.getY());
			bowAttackSpritesArray[i].setX(sprite.getX());
			bowAttackSpritesArray[i].setY(sprite.getY());
			crossbowSpritesArray[i].setX(sprite.getX());
			crossbowSpritesArray[i].setY(sprite.getY());
			crossbowStaySpritesArray[i].setX(sprite.getX());
			crossbowStaySpritesArray[i].setY(sprite.getY());
			crossbowAttackSpritesArray[i].setX(sprite.getX());
			crossbowAttackSpritesArray[i].setY(sprite.getY());
			oneHandSpritesArray[i].setX(sprite.getX());
			oneHandSpritesArray[i].setY(sprite.getY());
			oneHandStaySpritesArray[i].setX(sprite.getX());
			oneHandStaySpritesArray[i].setY(sprite.getY());
			oneHandAttackSpritesArray[i].setX(sprite.getX());
			oneHandAttackSpritesArray[i].setY(sprite.getY());
			twoHandSpritesArray[i].setX(sprite.getX());
			twoHandSpritesArray[i].setY(sprite.getY());
			twoHandStaySpritesArray[i].setX(sprite.getX());
			twoHandStaySpritesArray[i].setY(sprite.getY());
			twoHandAttackSpritesArray[i].setX(sprite.getX());
			twoHandAttackSpritesArray[i].setY(sprite.getY());
		}
	}
	
	public void changeVelocity(boolean directionArray[]){
		int count = 0;
		for(int i=0; i < directionArray.length; i++){
			if(directionArray[i] == false){
				count += 1;
			}
		}
		if (count == directionArray.length){
			sprite = stayArray[stayDirection];
			weaponSprite = weaponStayArray[stayDirection];
			behindSprite = behindStayArray[stayDirection];
		}else{
			setCoordinates();
			if(directionArray[0] == true){
				if(directionArray[2] == true){
					sprite = moveArray[5];
					weaponSprite = weaponMoveArray[5];
					behindSprite = behindMoveArray[5];
					sprite.setVelocityX(-velocity*Math.round((Math.sqrt(2)/2)));
					sprite.setVelocityY(-velocity*Math.round((Math.sqrt(2)/2)));
					stayDirection = 5;
				}else if(directionArray[3] == true){
					sprite = moveArray[3];
					weaponSprite = weaponMoveArray[3];
					behindSprite = behindMoveArray[3];
					sprite.setVelocityX(+velocity*Math.round((Math.sqrt(2)/2)));
					sprite.setVelocityY(-velocity*Math.round((Math.sqrt(2)/2)));
					stayDirection = 3;
				}else{
				sprite = moveArray[4];
				weaponSprite = weaponMoveArray[4];
				behindSprite = behindMoveArray[4];
				sprite.setVelocityY(-velocity);
				stayDirection = 4;
				}
			}else if(directionArray[1] == true){
				if(directionArray[2] == true){
					sprite = moveArray[7];
					weaponSprite = weaponMoveArray[7];
					behindSprite = behindMoveArray[7];
					sprite.setVelocityX(-velocity*Math.round((Math.sqrt(2)/2)));
					sprite.setVelocityY(+velocity*Math.round((Math.sqrt(2)/2)));
					stayDirection = 7;
				}else if(directionArray[3] == true){
					sprite = moveArray[1];
					weaponSprite = weaponMoveArray[1];
					behindSprite = behindMoveArray[1];
					sprite.setVelocityX(+velocity*Math.round((Math.sqrt(2)/2)));
					sprite.setVelocityY(+velocity*Math.round((Math.sqrt(2)/2)));
					stayDirection = 1;
				}else{
				sprite = moveArray[0];
				weaponSprite = weaponMoveArray[0];
				behindSprite = behindMoveArray[0];
				sprite.setVelocityY(velocity);
				stayDirection = 0;
				}
			}else if(directionArray[2] == true){
				sprite = moveArray[6];
				weaponSprite = weaponMoveArray[6];
				behindSprite = behindMoveArray[6];
				sprite.setVelocityX(-velocity);
				stayDirection = 6;
			}else if(directionArray[3] == true){
				sprite = moveArray[2];
				weaponSprite = weaponMoveArray[2];
				behindSprite = behindMoveArray[2];
				sprite.setVelocityX(+velocity);
				stayDirection = 2;
			}else{
				sprite.setVelocityY(0);
				sprite.setVelocityX(0);
			}
		}
	}

	public void takeWeapon(Weapon weapon){
		Weapon temp = this.weapon;
		this.weapon = weapon;
		this.weaponBehind = temp;
		setSprites();
	}
	public void changeWeapon(){
		Weapon temp = this.weapon;
		this.weapon = this.weaponBehind;
		this.weaponBehind = temp;
		setSprites();
	}
	public Image getImage(){
		return sprite.getImage();
	}
	public Sprite getSprite(){
		return sprite;
	}
	public Sprite getWeaponSprite(){
		return weaponSprite;
	}
	public Sprite getBehindSprite(){
		return behindSprite;
	}
	public Weapon getWeapon(){
		return weapon;
	}
	public Weapon getBehind(){
		return weaponBehind;
	}
}