import java.awt.Graphics2D;


public class Main extends Core{

	@Override
	public void draw(Graphics2D g) {
		// TODO Auto-generated method stub
		
	}
}
