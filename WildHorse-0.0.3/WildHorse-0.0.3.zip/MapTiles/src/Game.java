import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

public class Game extends Core implements KeyListener, MouseMotionListener, MouseListener, MouseWheelListener {
	public static void main(String[] args){
		new Game().run();
	}
	
	private String message = "";
	float mouseX, mouseY;
	float dx;
	float dy;
	Map map = new Map();
	Hero hero = new Hero();
	Sprite sprite;
	long startTime = System.currentTimeMillis();
	long cumulativeTime = startTime;
	boolean directionArray[] = {false, false, false, false}; // up, down, left, right
	int heroWidth, heroHeight, mapXLength, mapYLength, mapTileWidth, mapTileHeight, screenHeight, screenWidth;
	float heroVelocity;
	
	private void loadImages() {
		//load pics to game (no map pics)
	}
	
	public void init(){
		super.init();
		Window w = s.getFullScreenWindow();
		w.setFocusTraversalKeysEnabled(false); //enable weird buttons?
		w.addMouseListener(this);
		w.addMouseMotionListener(this);
		w.addMouseWheelListener(this);
		w.addKeyListener(this);
		map.main(null);
		hero.loadImages();
		
		mapXLength = map.mapSpritesArray[0].length;
		mapYLength = map.mapSpritesArray.length;
		mapTileWidth = map.mapSpritesArray[0][0].getWidth();
		mapTileHeight = map.mapSpritesArray[0][0].getHeight();
		screenHeight = s.getHeight();
		screenWidth = s.getWidth();
		heroVelocity = hero.getVelocity();
		
		loadImages();
		message = "press escape to exit";
	}

	public synchronized void draw(Graphics2D g){
		heroWidth = hero.getSprite().getWidth();
		heroHeight = hero.getSprite().getHeight();
		long time = System.currentTimeMillis();
		Window w = s.getFullScreenWindow();
		g.setColor(w.getBackground());
		g.fillRect(0, 0, s.getWidth(), s.getHeight());
		if (dy > 0){
			dy = 0;
		}else if(dy < -(mapYLength-4-(float)screenHeight/(float)mapTileHeight)*mapTileHeight){
			dy = -(mapYLength-4-(float)screenHeight/(float)mapTileHeight)*mapTileHeight;
		}
		if (dx > 0){
			dx = 0;
		}else if(dx < -(mapXLength-4-(float)screenWidth/(float)mapTileWidth)*mapTileWidth){
			dx = -(mapXLength-4-(float)screenWidth/(float)mapTileWidth)*mapTileWidth;
		}
		map.renderSprites(g, screenWidth, screenHeight, dx, dy);
		hero.changeVelocity(directionArray);
		g.drawImage(hero.getImage(), Math.round(hero.getSprite().getX()+dx)+mapTileWidth,Math.round(hero.getSprite().getY()+dy)+mapTileWidth, null);
		//message = ""+hero.getSprite().getX()+""+hero.getSprite().getY();
		g.setColor(Color.black);
		g.fillRect(0, 0, 57, 55);
		g.setColor(Color.white);
		message = ""+(System.currentTimeMillis() - time);
		g.drawString(message, 15, 30);
		
		long timePassed = System.currentTimeMillis() - cumulativeTime;
		cumulativeTime += timePassed;
		hero.getSprite().update(timePassed);
		testXY(hero.getSprite(), timePassed);
	}
	
	private void testXY(Sprite sprite, long time){
		heroWidth = sprite.getWidth();
		heroHeight = sprite.getHeight();
		float heroX = sprite.getX();
		float heroY = sprite.getY();
		if(sprite.getY() < 0){
			directionArray[0] = false;
			sprite.setY(0);
		}else if(heroY + heroHeight > mapTileHeight*(mapYLength-6)){
			directionArray[1] = false;
			sprite.setY(mapTileHeight*(mapYLength-6)-heroHeight);
		}if(heroX < 0){
			directionArray[2] = false;
			sprite.setX(0);
		}else if(heroX + heroWidth > mapTileWidth*(mapXLength-6)){
			directionArray[3] = false;
			sprite.setX(mapTileWidth*(mapXLength-6)-heroWidth);
		}
		
		if((heroX + heroWidth) < (screenWidth-dx) && (heroX + heroWidth) > (screenWidth-(mapTileWidth*3))-dx){
			dx -= heroVelocity*time;
		}
		if(heroX > -dx && heroX < mapTileWidth*3-dx){
			dx += heroVelocity*time;
		}
		if((heroY + heroHeight) < (screenHeight-dy) && (heroY + heroHeight) > (screenHeight-(mapTileHeight*3))-dy){
			dy -= heroVelocity*time;
		}
		if(heroY > -dy && heroY < mapTileHeight*3-dy){
			dy += heroVelocity*time;
		}
	}
	
	//key pressed
	public void keyPressed(KeyEvent e){
		int keyCode = e.getKeyCode();
		if (keyCode == KeyEvent.VK_ESCAPE){
			stop();
		}else {
			sprite = hero.getSprite();
			if (keyCode == KeyEvent.VK_UP){
				if(sprite.getY() > 2){
					directionArray[0] = true;
				}
			}
			if (keyCode == KeyEvent.VK_DOWN){
				if(sprite.getY() + heroHeight < mapTileHeight*(mapYLength-6)-2){
					directionArray[1] = true;
				}
			}
			if (keyCode == KeyEvent.VK_RIGHT){
				if(sprite.getX() + heroWidth < mapTileWidth*(mapXLength-6)-2){
					directionArray[3] = true;
				}
			}
			if (keyCode == KeyEvent.VK_LEFT){
				if(sprite.getX() > 2){
					directionArray[2] = true;
				}
			}
			message = "Pressed: " + KeyEvent.getKeyText(keyCode);
			e.consume();
		}
	}
	
	//key released
	public void keyReleased(KeyEvent e){
		int keyCode = e.getKeyCode();
		if (keyCode == KeyEvent.VK_UP){
			directionArray[0] = false;
		}
		if (keyCode == KeyEvent.VK_DOWN){
			directionArray[1] = false;
		}
		if (keyCode == KeyEvent.VK_RIGHT){
			directionArray[3] = false;
		}
		if(keyCode == KeyEvent.VK_LEFT){
			directionArray[2] = false;
		}
		e.consume();
	}
	public void keyTyped(KeyEvent e){
		e.consume();
	}

	public void mousePressed(MouseEvent e){
		message = "you pressed down the mouse";
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseReleased(MouseEvent e){
		message = "you released the mouse";
	}
	public void mouseClicked(MouseEvent e){
	}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseDragged(MouseEvent e){
		dx += e.getX() - mouseX;
		dy += e.getY() - mouseY;
		message = "you are dragging the mouse\n" + dx + "|" + dy;
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseMoved(MouseEvent e){
		message = "mouse is moving!";
	}
	public void mouseWheelMoved(MouseWheelEvent e){
		message = "moving mouse wheel";
	}
}