import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class Hero{

	private BufferedImage walkSprite;
	Sprite moveArray[];
	Sprite moveSpritesArray[] = new Sprite[8];
	Sprite staySpritesArray[] = new Sprite[8];
	Sprite sprite;
	private int spriteHeight = 99, spriteWidth = 75;
	private float velocity = 0.2f;
	
	public float getVelocity(){
		return velocity;
	}
	public void loadImages(){
		
		java.io.InputStream imgWalkSprite = this.getClass().getClassLoader().getResourceAsStream("walkSprite.gif");
		try {
			walkSprite = ImageIO.read(imgWalkSprite);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		
		int index = 0;
		for (int i = 0; i < walkSprite.getHeight()/spriteHeight; i++)
		{
			Animation animation = new Animation();
			Animation animationStay = new Animation();
			for (int j = 0; j < walkSprite.getWidth()/spriteWidth; j++)
			{
				BufferedImage sprite = walkSprite.getSubimage(j*spriteWidth, i*spriteHeight, spriteWidth, spriteHeight);
				animation.addScene(sprite, 100);
				if(j == 0){
				BufferedImage stay = walkSprite.getSubimage(0, i*spriteHeight, spriteWidth, spriteHeight);
				animationStay.addScene(stay, 0);
				staySpritesArray[index] = new Sprite(animationStay);
				}
			}
			moveSpritesArray[index] = new Sprite(animation); // d, dr, r, ur, u, ul, l, dl
			moveSpritesArray[index].setVelocityX(0);
			moveSpritesArray[index].setVelocityY(0);
			staySpritesArray[index].setVelocityX(0);
			staySpritesArray[index].setVelocityY(0);
			index++;
		}
		System.out.println("Hero move array is ready");
		sprite = staySpritesArray[0];
	}
	
	boolean directionArray[] = {false, false, false, false}; // up, down, left, right
	
	public void changeVelocity(boolean directionArray[]){
		int count = 0;
		for(int i=0; i < directionArray.length; i++){
			if(directionArray[i] == false){
				count += 1;
			}
		}
		if (count == directionArray.length){
			sprite = staySpritesArray[0];
		}else{
			if(directionArray[0] == true){
				if(directionArray[2] == true){
					sprite = moveSpritesArray[5];
				}else if(directionArray[3] == true){
					sprite = moveSpritesArray[3];
				}else{
				sprite = moveSpritesArray[4];}
				sprite.setVelocityY(-velocity);
			}else if(directionArray[1] == true){
				if(directionArray[2] == true){
					sprite = moveSpritesArray[7];
				}else if(directionArray[3] == true){
					sprite = moveSpritesArray[1];
				}else{
				sprite = moveSpritesArray[0];}
				sprite.setVelocityY(velocity);
			}else{
				sprite.setVelocityY(0);
			}
			if(directionArray[2] == true){
				if(directionArray[0] == true){
					sprite = moveSpritesArray[5];
				}else if(directionArray[1] == true){
					sprite = moveSpritesArray[7];
				}else{
				sprite = moveSpritesArray[6];}
				sprite.setVelocityX(-velocity);
			}else if(directionArray[3] == true){
				if(directionArray[0] == true){
					sprite = moveSpritesArray[3];
				}else if(directionArray[1] == true){
					sprite = moveSpritesArray[1];
				}else{
				sprite = moveSpritesArray[2];}
				sprite.setVelocityX(velocity);
			}else{
				sprite.setVelocityX(0);
			}
			for(int i=0; i < moveSpritesArray.length; i++){
				moveSpritesArray[i].setX(sprite.getX());
				moveSpritesArray[i].setY(sprite.getY());
				staySpritesArray[i].setX(sprite.getX());
				staySpritesArray[i].setY(sprite.getY());
			}
		}
	}

	public Image getImage(){
		return sprite.getImage();
	}
	public Sprite getSprite(){
		return sprite;
	}
}