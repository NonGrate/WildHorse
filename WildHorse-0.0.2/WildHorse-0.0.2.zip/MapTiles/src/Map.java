import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

import org.omg.CORBA.portable.InputStream;

public class Map {
	private static final String SNOW = null;
	private static final String SAND = "ffff00";
	private static final String RIVER = "0000ff";
	private static final String FIELD = "00ff00";
	private static final String FOREST = "008000";
	private static final String ROCKS = "ffffff";

	private static final String SAND_FIELD_FOREST = "ccff00";
	private static final String SAND_ROCKS = "cccc00";
	private static final String SAND_RIVER = "cccccc";
	private static final String SAND_SNOW = null;

	private static final String SNOW_SAND = null;
	private static final String SNOW_FIELD_FOREST = null;
	private static final String SNOW_ROCKS = null;
	private static final String SNOW_RIVER = null;
	
	private static final String FIELD_FOREST_SAND = "66ff00";
	private static final String FIELD_FOREST_ROCKS = "00cc00";
	private static final String FIELD_FOREST_RIVER = "00ff66";
	private static final String FIELD_FOREST_SNOW = null;

	private static final String ROCKS_SAND = "666600";
	private static final String ROCKS_FIELD_FOREST = "006600";
	private static final String ROCKS_RIVER = "000066";
	private static final String ROCKS_SNOW = null;
	
	private static final String RIVER_SAND = "666666";
	private static final String RIVER_FIELD_FOREST = "00ffcc";
	private static final String RIVER_ROCKS = "0000cc";
	private static final String RIVER_SNOW = null;

	private BufferedImage mapImage;
	private BufferedImage spriteSheet;
	Sprite mapSpritesArray[][];
	private Animation[] animationsArray;
	private float firstX, firstY, lastX, lastY;
	int tileX, tileY;
	
	public void main(String[] args){
		loadImages();
		getImageRGB();
	}

	public float getFirstX(){
		return firstX;
	}
	public float getFirstY(){
		return firstY;
	}
	public float getLastX(){
		return lastX;
	}
	public float getLastY(){
		return lastY;
	}
	
	public void loadImages(){

		java.io.InputStream imgSpriteSheet = this.getClass().getClassLoader().getResourceAsStream("spriteSheet.gif");
		java.io.InputStream imgMap = this.getClass().getClassLoader().getResourceAsStream("testMap.png");

		try {
			spriteSheet = ImageIO.read(imgSpriteSheet);
			mapImage = ImageIO.read(imgMap);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		// The above line throws an checked IOException which must be caught.

		mapSpritesArray = new Sprite[mapImage.getHeight()][mapImage.getWidth()];
		animationsArray = new Animation[spriteSheet.getHeight()*spriteSheet.getWidth()];
		int index = 0;
		for (int i = 0; i < spriteSheet.getHeight()/64; i++)
		{
		    for (int j = 0; j < spriteSheet.getWidth()/64; j++)
		    {
		    	BufferedImage sprite = spriteSheet.getSubimage(j*64, i*64, (int)64, (int)64);
		    	Animation animation = new Animation();
		    	animation.addScene(sprite, 0);
		    	animationsArray[index] = animation;
		    	index++;
			}
		}
		System.out.println("Map array is ready");
	}
	public void getImageRGB(){
		for (int y = 0; y < mapImage.getHeight(); y++) {
			for (int x = 0; x < mapImage.getWidth(); x++) {
		    	int clr = mapImage.getRGB(x, y);
		    	String rgb = Integer.toHexString(clr);
		    	rgb = rgb.substring(2, rgb.length());
				if(rgb.equalsIgnoreCase(SAND)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[0]);
				}else if(rgb.equalsIgnoreCase(FIELD)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[1]);
				}else if(rgb.equalsIgnoreCase(SNOW)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[2]);
				}else if(rgb.equalsIgnoreCase(ROCKS)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[3]);
				}else if(rgb.equalsIgnoreCase(RIVER)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[4]);
				}
				else if(rgb.equalsIgnoreCase(SAND_FIELD_FOREST)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[5]);
				}else if(rgb.equalsIgnoreCase(SAND_SNOW)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[6]);
				}else if(rgb.equalsIgnoreCase(SAND_ROCKS)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[7]);
				}else if(rgb.equalsIgnoreCase(SAND_RIVER)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[8]);
				}
				else if(rgb.equalsIgnoreCase(FIELD_FOREST_SAND)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[9]);
				}else if(rgb.equalsIgnoreCase(FIELD_FOREST_SNOW)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[10]);
				}else if(rgb.equalsIgnoreCase(FIELD_FOREST_ROCKS)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[11]);
				}else if(rgb.equalsIgnoreCase(FIELD_FOREST_RIVER)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[12]);
				}
				else if(rgb.equalsIgnoreCase(ROCKS_SAND)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[13]);
				}else if(rgb.equalsIgnoreCase(ROCKS_SNOW)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[14]);
				}else if(rgb.equalsIgnoreCase(ROCKS_FIELD_FOREST)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[15]);
				}else if(rgb.equalsIgnoreCase(ROCKS_RIVER)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[16]);
				}
				else if(rgb.equalsIgnoreCase(RIVER_SAND)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[17]);
				}else if(rgb.equalsIgnoreCase(RIVER_SNOW)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[18]);
				}else if(rgb.equalsIgnoreCase(RIVER_FIELD_FOREST)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[19]);
				}else if(rgb.equalsIgnoreCase(RIVER_ROCKS)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[20]);
				}
				else if(rgb.equalsIgnoreCase(SNOW_SAND)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[21]);
				}else if(rgb.equalsIgnoreCase(SNOW_FIELD_FOREST)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[22]);
				}else if(rgb.equalsIgnoreCase(SNOW_ROCKS)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[23]);
				}else if(rgb.equalsIgnoreCase(SNOW_RIVER)){
					mapSpritesArray[y][x] = new Sprite(animationsArray[24]);
				}else if(rgb.equalsIgnoreCase("000000")){
					mapSpritesArray[y][x] = new Sprite(animationsArray[25]);
				}else{
					mapSpritesArray[y][x] = new Sprite(animationsArray[25]);
					System.out.println("no color"+rgb);
				}
				mapSpritesArray[y][x].setVelocityX(0);
				mapSpritesArray[y][x].setVelocityY(0);
			}
		}
		tileX = mapSpritesArray[0][0].getWidth();
		tileY = mapSpritesArray[0][0].getHeight();
		System.out.println("Image RGB is ready");
	}
	
	private static int roundDown(float f){
		int num = 0;
		if (f > 0){
			while(f > 1){
				f -= 1;
				num++;
			}
		}else if(f < 0){
			while(f < -1){
				f += 1;
				num--;
			}
		}
		return num;
	}
	
	public void renderSprites(Graphics2D g, int width, int height, float dx, float dy){
		int startX = -2;
		int startY = -2;
		int saveX = startX;
		g.setColor(Color.black);
		g.fillRect(0, 0, width, height);
		for(float y = 0; y <= height/mapSpritesArray[0][0].getHeight()+4; y++){
			for(float x = 0; x <= width/mapSpritesArray[0][0].getWidth()+4; x++){
				g.drawImage(
					mapSpritesArray[Math.round(y)-roundDown(dy/tileY)][Math.round(x)-roundDown(dx/tileX)].getImage(),
					tileX*(startX - roundDown(dx/tileX))+Math.round(dx),
					tileY*(startY - roundDown(dy/tileY))+Math.round(dy), null);
				g.drawString(""+dy, 200, 200);
				startX++;
			}
			startY++;
			startX = saveX;
		}
		
		// TODO Надо сделать подгрузку тайлов, чтобы они подгружались при прокрутке - готово
		// TODO Надо сделать остановку, если тайлы закончились. (край карты) - готово
		// TODO Надо сделать так, чтобы не дергалось - готово
		// TODO Надо сделать, чтобы не дергалось
		// TODO Надо человечка посадить внутрь
		// TODO Надо деревья сделать, и чтобы чувак о них стукался
		// TODO Надо это запилить куда-нибудь
	}
}