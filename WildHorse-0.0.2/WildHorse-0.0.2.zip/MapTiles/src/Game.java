import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

public class Game extends Core implements KeyListener, MouseMotionListener, MouseListener, MouseWheelListener {
	public static void main(String[] args){
		new Game().run();
	}
	
	private String message = "";
	float mouseX, mouseY;
	float dx;
	float dy;
	private String picPath = "/home/arsenii/Eclipse Workspace/MapTiles/resources/";
	Map map = new Map();
	
	private void loadImages() {
		//load pics to game (no map pics)
	}
	
	public void init(){
		super.init();
		Window w = s.getFullScreenWindow();
		w.setFocusTraversalKeysEnabled(false); //enable weird buttons?
		w.addMouseListener(this);
		w.addMouseMotionListener(this);
		w.addMouseWheelListener(this);
		w.addKeyListener(this);
		map.main(null);
		loadImages();
		message = "press escape to exit";
	}

	public synchronized void draw(Graphics2D g){
		long time = System.currentTimeMillis();
		Window w = s.getFullScreenWindow();
		g.setColor(w.getBackground());
		g.fillRect(0, 0, s.getWidth(), s.getHeight());
		if(dy > 0){
			dy = 0;
		}else if(dy < -(map.mapSpritesArray.length-4-(float)s.getHeight()/(float)map.mapSpritesArray[0][0].getHeight())*map.mapSpritesArray[0][0].getHeight()){
			dy = -(map.mapSpritesArray.length-4-(float)s.getHeight()/(float)map.mapSpritesArray[0][0].getHeight())*map.mapSpritesArray[0][0].getHeight();
		}
		if (dx > 0){
			dx = 0;
		}else if(dx < -(map.mapSpritesArray[0].length-4-(float)s.getWidth()/(float)map.mapSpritesArray[0][0].getWidth())*map.mapSpritesArray[0][0].getWidth()){
			dx = -(map.mapSpritesArray[0].length-4-(float)s.getWidth()/(float)map.mapSpritesArray[0][0].getWidth())*map.mapSpritesArray[0][0].getWidth();
		}
		map.renderSprites(g, s.getWidth(), s.getHeight(), dx, dy);
		g.setColor(Color.black);
		g.fillRect(0, 0, 215, 50);
		g.setColor(Color.white);
		message = ""+(System.currentTimeMillis() - time);
		g.drawString(message, 15, 30);
	}

	//key pressed
	public void keyPressed(KeyEvent e){
		int keyCode = e.getKeyCode();
		if (keyCode == KeyEvent.VK_ESCAPE){
			stop();
		}else if(keyCode == KeyEvent.VK_RIGHT){
			dx -= 2;
		}else if(keyCode == KeyEvent.VK_LEFT){
			dx += 2;
		}else if(keyCode == KeyEvent.VK_UP){
			dy += 2;
		}else if(keyCode == KeyEvent.VK_DOWN){
			dy -= 2;
		}else{
			message = "Pressed: " + KeyEvent.getKeyText(keyCode);
			e.consume();
		}
	}
	
	//key released
	public void keyReleased(KeyEvent e){
		int keyCode = e.getKeyCode();
		message = "Released: " + KeyEvent.getKeyText(keyCode);
		e.consume();
	}
	public void keyTyped(KeyEvent e){
		e.consume();
	}

	public void mousePressed(MouseEvent e){
		message = "you pressed down the mouse";
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseReleased(MouseEvent e){
		message = "you released the mouse";
	}
	public void mouseClicked(MouseEvent e){
	}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseDragged(MouseEvent e){
		dx += e.getX() - mouseX;
		dy += e.getY() - mouseY;
		message = "you are dragging the mouse\n" + dx + "|" + dy;
		mouseX = e.getX();
		mouseY = e.getY();
	}
	public void mouseMoved(MouseEvent e){
		message = "mouse is moving!";
	}
	public void mouseWheelMoved(MouseWheelEvent e){
		message = "moving mouse wheel";
	}
}