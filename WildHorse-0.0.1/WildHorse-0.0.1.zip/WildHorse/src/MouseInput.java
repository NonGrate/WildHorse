import java.awt.*;
import java.awt.event.*;
import java.io.File;

import javax.swing.ImageIcon;

public class MouseInput extends Core implements KeyListener, MouseMotionListener, MouseListener, MouseWheelListener {
	public static void main(String[] args){
		new MouseInput().run();
	}
	
	private Sprite spriteStay;
	private Sprite spriteMove;
	private Sprite sprite;
	private Animation aStay;
	private Animation aMove;
	private Image bg;
	private float velocity = 0.3f;
	long startTime = System.currentTimeMillis();
	long cumulativeTime = startTime;
	boolean directionArray[] = {false, false, false, false}; // up, down, left, right
	
	private void changeVelocity(boolean directionArray[]){
		int count = 0;
		for(int i=0; i < directionArray.length; i++){
			if(directionArray[i] == false){
				count += 1;
			}
		}
		if (count == directionArray.length){
			spriteStay.setX(sprite.getX());
			spriteStay.setY(sprite.getY());
			sprite = spriteStay;
		}else{
			if(directionArray[0] == true){
				sprite.setVelocityY(-velocity);
			}else if(directionArray[1] == true){
				sprite.setVelocityY(velocity);
			}else{
				sprite.setVelocityY(0);
			}
			if(directionArray[2] == true){
				sprite.setVelocityX(-velocity);
			}else if(directionArray[3] == true){
				sprite.setVelocityX(velocity);
			}else{
				sprite.setVelocityX(0);
			}
		}
	}
	
	private void loadImages() {
		bg = new ImageIcon("res/back-big.jpg").getImage();
		Image picStay = new ImageIcon ("res/man_stay.png").getImage();
		Image picMove1 = new ImageIcon ("res/man_move.png").getImage();
		//Image picMove2 = new ImageIcon ("/home/arsenii/Eclipse Workspace/JavaBasic/resources/man_move2.png").getImage();
		aStay = new Animation();
		aMove = new Animation();
		aStay.addScene(picStay, 150);
		aMove.addScene(picStay, 150);
		aMove.addScene(picMove1, 150);
		spriteStay = new Sprite(aStay);
		spriteMove = new Sprite(aMove);
		spriteStay.setVelocityX(0);
		spriteStay.setVelocityY(0);
		spriteMove.setVelocityX(0);
		spriteMove.setVelocityY(0);
		sprite = spriteStay;
	}
	
	private String message = "";
	private String messageVelX = ""; // delete
	private String messageVelY = ""; // delete
	private String messageTrueX = ""; // delete
	private String messageTrueY = ""; // delete
	private String messageOneMore = ""; // delete
	
	public void init(){
		super.init();
		loadImages();
		Window w = s.getFullScreenWindow();
		w.addMouseListener(this);
		w.addMouseMotionListener(this);
		w.addMouseWheelListener(this);
		w.addKeyListener(this);
	}
	
	public synchronized void draw(Graphics2D g){
		Window w = s.getFullScreenWindow();
		g.setColor(w.getBackground());
		g.drawImage(bg, 0, 0, null);
		changeVelocity(directionArray);
		g.setColor(w.getForeground());
		g.drawString(message, 100, 100);
		g.drawString(""+(System.currentTimeMillis() - cumulativeTime), 10, 30);
		g.drawString(messageVelX, 100, 200); // delete
		g.drawString(messageVelY, 100, 230); // delete
		g.drawString(messageTrueX, 100, 260); // delete
		g.drawString(messageTrueY, 100, 290); // delete
		g.drawString(messageOneMore, 100, 320); // delete
		g.drawImage(sprite.getImage(), Math.round(sprite.getX()), Math.round(sprite.getY()), null);
		messageVelX = String.format("%.2f", sprite.getVelocityX()); // delete
		messageVelY = String.format("%.2f", sprite.getVelocityY()); // delete
		
		long timePassed = System.currentTimeMillis() - cumulativeTime;
		cumulativeTime += timePassed;
		sprite.update(timePassed);
	}

	//key pressed
	public void keyPressed(KeyEvent e){
		int keyCode = e.getKeyCode();
		if (keyCode == KeyEvent.VK_ESCAPE){
			stop();
		}else {
			if (keyCode == KeyEvent.VK_UP){
				sprite = spriteMove;
				if(sprite.getY() > 0){
					messageTrueY = "True"; // delete
					directionArray[0] = true;
				}else{
					//directionArray[0] = false;
					messageTrueY = "False"; // delete
				}
			}
			if (keyCode == KeyEvent.VK_DOWN){
				sprite = spriteMove;
				if(sprite.getY() + sprite.getHeight() < s.getHeight()){
					messageTrueY = "True"; // delete
					directionArray[1] = true;
				}else{
					//directionArray[1] = false;
					messageTrueY = "True"; // delete
				}
			}
			if (keyCode == KeyEvent.VK_RIGHT){
				sprite = spriteMove;
				if(sprite.getX() + sprite.getWidth() < s.getWidth()){
					messageTrueX = "True"; // delete
					directionArray[3] = true;
				}else{
					//directionArray[3] = false;
					messageTrueX = "False"; // delete
				}
			}
			if (keyCode == KeyEvent.VK_LEFT){
				sprite = spriteMove;
				if(sprite.getX() > 0){
					messageTrueX = "True"; // delete
					directionArray[2] = true;
				}else{
					//directionArray[2] = false;
					messageTrueX = "False"; // delete
				}
			}
			message = "Pressed: " + KeyEvent.getKeyText(keyCode);
			e.consume();
		}
	}
	
	//key released
	public void keyReleased(KeyEvent e){
		int keyCode = e.getKeyCode();
		messageOneMore = Integer.toString(keyCode);
		if (keyCode == KeyEvent.VK_UP){
			directionArray[0] = false;
		}
		if (keyCode == KeyEvent.VK_DOWN){
			directionArray[1] = false;
		}
		if (keyCode == KeyEvent.VK_RIGHT){
			directionArray[3] = false;
		}
		if(keyCode == KeyEvent.VK_LEFT){
			directionArray[2] = false;
		}
		e.consume();
		message = "Released: " + KeyEvent.getKeyText(keyCode);
		messageVelX = String.format("%.2f", sprite.getVelocityX()); // delete
		messageVelY = String.format("%.2f", sprite.getVelocityY()); // delete
	}
	
	public void keyTyped(KeyEvent e){
		e.consume();
	}


	//listener
	public void mousePressed(MouseEvent e){
		message = "you pressed down the mouse";
	}
	
	public void mouseReleased(MouseEvent e){
		message = "you released the mouse";
	}
	
	public void mouseClicked(MouseEvent e){}
	
	public void mouseEntered(MouseEvent e){}
	
	public void mouseExited(MouseEvent e){}
	
	//motion
	public void mouseDragged(MouseEvent e){
		message = "you are dragging the mouse";
	}
	
	public void mouseMoved(MouseEvent e){
		message = "mouse is moving!";
	}
	
	//wheel
	public void mouseWheelMoved(MouseWheelEvent e){
		message = "moving mouse wheel";
	}
}